﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Juego
{
    class Obstaculos
    {
        private Meteorito [] meteoritos;
        Random r;
        
        public Obstaculos(int n,int ancho, int alto)
        {
            meteoritos = new Meteorito[n];
            r = new Random();
            for (int i=0;i<=n; i++)
            {
                meteoritos[i] = new Meteorito(alto,ancho,r);
            }
        }
        public void Dibujar(Graphics graphics)
        {
            for (int i = 0; i <= meteoritos.Length; i++)
            {
                meteoritos[i].Dibujar(graphics);
            }

        }
        public void Mover()
        {
            for (int i = 0; i <= meteoritos.Length; i++)
            {
                meteoritos[i].Mover();
            }
        }

    }
}
