﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace Juego
{
    
    class Nave
    {
        private double x;
        private double y;
        private double ancho;
        private double alto;
        private double radio;

        private double dir;
        private bool estado;
        public Nave(double ancho, double alto)
        {
            this.ancho = ancho;
            this.alto = alto;
            radio = 10;

            this.x = ancho / 2;
            this.y = 0;
            this.dir = 1;
            this.estado = false;
        }
        public void Mover(int dx, int dy)
        {
            x += dx;
            y += dy;
        }

        public void Dibujar(Graphics graphics)
        {
            graphics.FillRectangle(Brushes.Blue,
                (int)(x - radio), (int)(y - radio),
                (int)(2 * radio), (int)(2 * radio));
        }

        internal void SetXY(int x, int y)
        {
            this.x = x;
            this.y = y;
        }
    }
}
