﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace Juego
{
    class Meteorito
    {
        private int x, y;
        private int ancho, alto;
        private int radio;

        private int retraso;
        
        private Random r;
        public Meteorito(int ancho,int alto, Random r)
        {
            this.ancho = ancho;
            this.alto = alto;
            this.r = r;
            Inicializar();
            
        }
        private void Inicializar()
        {
            radio = r.Next(1, 10) * 5;
            x = r.Next(radio, ancho - radio);
            y = -radio;
            retraso = r.Next(100, 250);
        }
        public void Dibujar(Graphics g)
        {
            g.FillEllipse(Brushes.Blue,
                (int)(x - radio), (int)(y - radio),
                (int)(2 * radio), (int)(2 * radio));
        }
        public void Mover()
        {
            if (retraso <= 0)
            {
                if (y - radio >= alto)
                    Inicializar();
                else
                    y += (radio / 2);
            }
            else
                retraso--;
        }
    }
}
