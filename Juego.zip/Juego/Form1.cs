﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Juego
{
    
    public partial class WinJuego : Form
    {
        private Nave n;
        private Obstaculos obstaculos;
        public WinJuego()
        {
            InitializeComponent();
            n = new Nave(areaGalaxia.Width, areaGalaxia.Height);
            obstaculos = new Obstaculos(10, areaGalaxia.Width, areaGalaxia.Height);
        }

        private void BotonSalir_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void areaGalaxia_Paint(object sender, PaintEventArgs e)
        {
            n.Dibujar(e.Graphics);
            obstaculos.Dibujar(e.Graphics);
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            obstaculos.Mover();
            areaGalaxia.Invalidate();
        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            switch (keyData)
            {
                case Keys.Up:
                case Keys.I:
                    n.Mover(0, -1);
                    areaGalaxia.Invalidate();
                    return true;
                case Keys.Down:
                case Keys.K:
                    n.Mover(0, 1);
                    areaGalaxia.Invalidate();
                    return true;
                case Keys.Left:
                case Keys.J:
                    n.Mover(-1, 0);
                    areaGalaxia.Invalidate();
                    return true;
                case Keys.Right:
                case Keys.L:
                    n.Mover(1, 0);
                    areaGalaxia.Invalidate();
                    return true;
            }

            return base.ProcessCmdKey(ref msg, keyData);
        }
    }
}
