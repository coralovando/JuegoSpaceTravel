﻿namespace Juego
{
    partial class WinJuego
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.process1 = new System.Diagnostics.Process();
            this.process2 = new System.Diagnostics.Process();
            this.BotonPausar = new System.Windows.Forms.Button();
            this.BotonSalir = new System.Windows.Forms.Button();
            this.LabelPuntaje = new System.Windows.Forms.Label();
            this.LabelNivel = new System.Windows.Forms.Label();
            this.LabelNombre = new System.Windows.Forms.Label();
            this.areaGalaxia = new System.Windows.Forms.PictureBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.areaGalaxia)).BeginInit();
            this.SuspendLayout();
            // 
            // process1
            // 
            this.process1.StartInfo.Domain = "";
            this.process1.StartInfo.LoadUserProfile = false;
            this.process1.StartInfo.Password = null;
            this.process1.StartInfo.StandardErrorEncoding = null;
            this.process1.StartInfo.StandardOutputEncoding = null;
            this.process1.StartInfo.UserName = "";
            this.process1.SynchronizingObject = this;
            // 
            // process2
            // 
            this.process2.StartInfo.Domain = "";
            this.process2.StartInfo.LoadUserProfile = false;
            this.process2.StartInfo.Password = null;
            this.process2.StartInfo.StandardErrorEncoding = null;
            this.process2.StartInfo.StandardOutputEncoding = null;
            this.process2.StartInfo.UserName = "";
            this.process2.SynchronizingObject = this;
            // 
            // BotonPausar
            // 
            this.BotonPausar.Location = new System.Drawing.Point(450, 13);
            this.BotonPausar.Name = "BotonPausar";
            this.BotonPausar.Size = new System.Drawing.Size(75, 23);
            this.BotonPausar.TabIndex = 1;
            this.BotonPausar.Text = "Pausar";
            this.BotonPausar.UseVisualStyleBackColor = true;
            // 
            // BotonSalir
            // 
            this.BotonSalir.Location = new System.Drawing.Point(450, 57);
            this.BotonSalir.Name = "BotonSalir";
            this.BotonSalir.Size = new System.Drawing.Size(75, 23);
            this.BotonSalir.TabIndex = 2;
            this.BotonSalir.Text = "Salir";
            this.BotonSalir.UseVisualStyleBackColor = true;
            this.BotonSalir.Click += new System.EventHandler(this.BotonSalir_Click);
            // 
            // LabelPuntaje
            // 
            this.LabelPuntaje.AutoSize = true;
            this.LabelPuntaje.Location = new System.Drawing.Point(455, 134);
            this.LabelPuntaje.Name = "LabelPuntaje";
            this.LabelPuntaje.Size = new System.Drawing.Size(55, 13);
            this.LabelPuntaje.TabIndex = 3;
            this.LabelPuntaje.Text = "Puntaje: 0";
            // 
            // LabelNivel
            // 
            this.LabelNivel.AutoSize = true;
            this.LabelNivel.Location = new System.Drawing.Point(456, 168);
            this.LabelNivel.Name = "LabelNivel";
            this.LabelNivel.Size = new System.Drawing.Size(43, 13);
            this.LabelNivel.TabIndex = 4;
            this.LabelNivel.Text = "Nivel: 0";
            // 
            // LabelNombre
            // 
            this.LabelNombre.AutoSize = true;
            this.LabelNombre.Location = new System.Drawing.Point(455, 98);
            this.LabelNombre.Name = "LabelNombre";
            this.LabelNombre.Size = new System.Drawing.Size(44, 13);
            this.LabelNombre.TabIndex = 5;
            this.LabelNombre.Text = "Nombre";
            // 
            // areaGalaxia
            // 
            this.areaGalaxia.Location = new System.Drawing.Point(13, 13);
            this.areaGalaxia.Name = "areaGalaxia";
            this.areaGalaxia.Size = new System.Drawing.Size(406, 375);
            this.areaGalaxia.TabIndex = 0;
            this.areaGalaxia.TabStop = false;
            this.areaGalaxia.Paint += new System.Windows.Forms.PaintEventHandler(this.areaGalaxia_Paint);
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // WinJuego
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(553, 400);
            this.Controls.Add(this.LabelNombre);
            this.Controls.Add(this.LabelNivel);
            this.Controls.Add(this.LabelPuntaje);
            this.Controls.Add(this.BotonSalir);
            this.Controls.Add(this.BotonPausar);
            this.Controls.Add(this.areaGalaxia);
            this.Name = "WinJuego";
            this.Text = "Juego";
            ((System.ComponentModel.ISupportInitialize)(this.areaGalaxia)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox areaGalaxia;
        private System.Diagnostics.Process process1;
        private System.Windows.Forms.Label LabelNombre;
        private System.Windows.Forms.Label LabelNivel;
        private System.Windows.Forms.Label LabelPuntaje;
        private System.Windows.Forms.Button BotonSalir;
        private System.Windows.Forms.Button BotonPausar;
        private System.Diagnostics.Process process2;
        private System.Windows.Forms.Timer timer1;
    }
}

